/*

 ofxWinMenu basic example - ofApp.cpp

 Example of using ofxWinMenu addon to create a menu for a Microsoft Windows application.

 Copyright (C) 2016-2017 Lynn Jarvis.

 https://github.com/leadedge

 http://www.spout.zeal.co

 =========================================================================
 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU Lesser General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
 =========================================================================

 03.11.16 - minor comment cleanup
 21.02.17 - rebuild for OF 0.9.8

*/
#include "ofApp.h"
#include <iostream>


using namespace std;
//--------------------------------------------------------------
void ofApp::setup() {

    ofSetWindowTitle("Maze Example"); // Set the app name on the title bar
    ofSetFrameRate(15);
    ofBackground(255, 255, 255);
    // Get the window size for image loading
    windowWidth = ofGetWidth();
    windowHeight = ofGetHeight();
    isdfs = false;
    isOpen = 0;
    // Centre on the screen
    ofSetWindowPosition((ofGetScreenWidth() - windowWidth) / 2, (ofGetScreenHeight() - windowHeight) / 2);

    // Load a font rather than the default
    myFont.loadFont("verdana.ttf", 12, true, true);

    // Load an image for the example
    //myImage.loadImage("lighthouse.jpg");

    // Window handle used for topmost function
    hWnd = WindowFromDC(wglGetCurrentDC());

    // Disable escape key exit so we can exit fullscreen with Escape (see keyPressed)
    ofSetEscapeQuitsApp(false);

    //
    // Create a menu using ofxWinMenu
    //

    // A new menu object with a pointer to this class
    menu = new ofxWinMenu(this, hWnd);

    // Register an ofApp function that is called when a menu item is selected.
    // The function can be called anything but must exist. 
    // See the example "appMenuFunction".
    menu->CreateMenuFunction(&ofApp::appMenuFunction);

    // Create a window menu
    HMENU hMenu = menu->CreateWindowMenu();

    //
    // Create a "File" popup menu
    //
    HMENU hPopup = menu->AddPopupMenu(hMenu, "File");

    //
    // Add popup items to the File menu
    //

    // Open an maze file
    menu->AddPopupItem(hPopup, "Open", false, false); // Not checked and not auto-checked

    // Final File popup menu item is "Exit" - add a separator before it
    menu->AddPopupSeparator(hPopup);
    menu->AddPopupItem(hPopup, "Exit", false, false);

    //
    // View popup menu
    //
    hPopup = menu->AddPopupMenu(hMenu, "View");

    bShowInfo = true;  // screen info display on
    menu->AddPopupItem(hPopup, "Show DFS", false, false); // Checked
    bTopmost = false; // app is topmost
    menu->AddPopupItem(hPopup, "Show BFS"); // Not checked (default)
    bFullscreen = false; // not fullscreen yet
    menu->AddPopupItem(hPopup, "Full screen", false, false); // Not checked and not auto-check

    //
    // Help popup menu
    //
    hPopup = menu->AddPopupMenu(hMenu, "Help");
    menu->AddPopupItem(hPopup, "About", false, false); // No auto check

    // Set the menu to the window
    menu->SetWindowMenu();

} // end Setup


//
// Menu function
//
// This function is called by ofxWinMenu when an item is selected.
// The the title and state can be checked for required action.
// 
void ofApp::appMenuFunction(string title, bool bChecked) {

    ofFileDialogResult result;
    string filePath;
    size_t pos;

    //
    // File menu
    //
    if (title == "Open") {
        readFile();
    }
    if (title == "Exit") {
        if (isOpen) {
            freeMemory();
            cout << "Dynamically allocated memories freed" << endl;
        }
        ofExit(); // Quit the application
    }

    //
    // Window menu
    //
    if (title == "Show DFS") {
        //bShowInfo = bChecked;  // Flag is used elsewhere in Draw()
        if (isOpen)
        {
            DFS();
            bShowInfo = bChecked;
        }
        else
            cout << "you must open file first" << endl;

    }

    if (title == "Show BFS") {
        doTopmost(bChecked); // Use the checked value directly

    }

    if (title == "Full screen") {
        bFullscreen = !bFullscreen; // Not auto-checked and also used in the keyPressed function
        doFullScreen(bFullscreen); // But als take action immediately
    }

    //
    // Help menu
    //
    if (title == "About") {
        ofSystemx - x - alertDialog("ofxWinMenu\nbasic example\n\nhttp://spout.zeal.co");
    }

} // end appMenuFunction


//--------------------------------------------------------------
void ofApp::update() {

}


//--------------------------------------------------------------
void ofApp::draw() {

    char str[256];
    //ofBackground(0, 0, 0, 0);
    ofSetColor(100);
    ofSetLineWidth(5);
    int i, j;

    // TO DO : DRAW MAZE; 
    // ����� �ڷᱸ���� �̿��� �̷θ� �׸���.
    // add code here

    int n = 0;
    int x = 30;
    int y = 5;
    int line = 35;

    if (isOpen) {
        for (i = 0; i < height_graph; i++) {
            for (j = 0; j < width_graph; j++) {
                if (graph[n]->link[0] == NULL) {
                    ofDrawLine(x, y, x + line, y);
                }
                if (graph[n]->link[1] == NULL) {
                    ofDrawLine(x + line, y, x + line, y + line);
                }
                if (graph[n]->link[2] == NULL) {
                    ofDrawLine(x, y + line, x + line, y + line);
                }
                if (graph[n]->link[3] == NULL) {
                    ofDrawLine(x, y, x, y + line);
                }
                x = x + line;
                n++;
            }
            x = 30;
            y = y + line;
        }
    }


    if (isdfs)
    {
        ofSetColor(200);
        ofSetLineWidth(5);
        if (isOpen)
            dfsdraw();
        else
            cout << "You must open file first" << endl;
    }
    if (bShowInfo) {
        // Show keyboard duplicates of menu functions
        sprintf(str, " comsil project");
        myFont.drawString(str, 15, ofGetHeight() - 20);
    }
} // end Draw







void ofApp::doFullScreen(bool bFull)
{
    // Enter full screen
    if (bFull) {
        // Remove the menu but don't destroy it
        menu->RemoveWindowMenu();
        // hide the cursor
        ofHideCursor();
        // Set full screen
        ofSetFullscreen(true);
    }
    else {
        // return from full screen
        ofSetFullscreen(false);
        // Restore the menu
        menu->SetWindowMenu();
        // Restore the window size allowing for the menu
        ofSetWindowShape(windowWidth, windowHeight + GetSystemMetrics(SM_CYMENU));
        // Centre on the screen
        ofSetWindowPosition((ofGetScreenWidth() - ofGetWidth()) / 2, (ofGetScreenHeight() - ofGetHeight()) / 2);
        // Show the cursor again
        ofShowCursor();
        // Restore topmost state
        if (bTopmost) doTopmost(true);
    }

} // end doFullScreen


void ofApp::doTopmost(bool bTop)
{
    if (bTop) {
        // get the current top window for return
        hWndForeground = GetForegroundWindow();
        // Set this window topmost
        SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
        ShowWindow(hWnd, SW_SHOW);
    }
    else {
        SetWindowPos(hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
        ShowWindow(hWnd, SW_SHOW);
        // Reset the window that was topmost before
        if (GetWindowLong(hWndForeground, GWL_EXSTYLE) & WS_EX_TOPMOST)
            SetWindowPos(hWndForeground, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
        else
            SetWindowPos(hWndForeground, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
    }
} // end doTopmost


//--------------------------------------------------------------
void ofApp::keyPressed(int key) {

    // Escape key exit has been disabled but it can be checked here
    if (key == VK_ESCAPE) {
        // Disable fullscreen set, otherwise quit the application as usual
        if (bFullscreen) {
            bFullscreen = false;
            doFullScreen(false);
        }
        else {
            ofExit();
        }
    }

    // Remove or show screen info
    if (key == ' ') {
        bShowInfo = !bShowInfo;
        // Update the menu check mark because the item state has been changed here
        menu->SetPopupItem("Show DFS", bShowInfo);
    }

    if (key == 'f') {
        bFullscreen = !bFullscreen;
        doFullScreen(bFullscreen);
        // Do not check this menu item
        // If there is no menu when you call the SetPopupItem function it will crash
    }

} // end keyPressed

//--------------------------------------------------------------
void ofApp::keyReleased(int key) {

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h) {

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg) {

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo) {

}
bool ofApp::readFile() {
    int i, j, command;
    ofFileDialogResult openFileResult = ofSystemLoadDialog("Select .maz file");
    string filePath;
    size_t pos;

    // Check whether the user opened a file
    if (openFileResult.bSuccess) {
        ofLogVerbose("User selected a file");
        // We have a file, check it and process it
        string fileName = openFileResult.getName();
        // string fileName = "maze0.maz";
        cout << "file name is " << fileName << endl;
        // printf("file name is %s\n", fileName); -> ���� �̸� ����� �̻��ϴ�.
        filePath = openFileResult.getPath();
        printf("Open\n");
        pos = filePath.find_last_of(".");
        if (pos != string::npos && pos != 0 && filePath.substr(pos + 1) == "maz") {
            ofFile file(fileName);
            if (!file.exists()) {
                cout << "Target file does not exists." << endl;
                return false;
            }
            else {
                cout << "We found the target file." << endl;
                isOpen = 1;
            }
            ofBuffer buffer(file);


            //2���� �ǽ� todo
            for (auto& line : buffer.getLines()) {
                ++HEIGHT;
                WIDTH = std::max(WIDTH, static_cast<int>(line.size()));
            }
            maze = new int* [HEIGHT];
            std::vector<std::vector<int>> maze;
            for (int i = 0; i < HEIGHT; ++i) {
                maze.emplace_back(WIDTH);
            }
            i = 0;
            cout << "HEIGHT: " << HEIGHT << " WIDTH: " << WIDTH << endl;
            for (auto it = buffer.getLines().begin(); it != buffer.getLines().end(); ++it, ++i) {
                string line = *it;
                for (int j = 0; j < WIDTH; ++j) {
                    char symbol = line[j];
                    switch (symbol) {
                    case '+': maze[i][j] = 1;
                        break;
                    case '-': maze[i][j] = 2;
                        break;
                    case '|': maze[i][j] = 3;
                        break;
                    default:
                        if ((i % 2 == 1 && j % 2 == 0) || (i % 2 == 0 && j % 2 == 1)) {
                            if (symbol == ' ')
                                maze[i][j] = 4;
                            else
                                maze[i][j] = 0;
                        }
                        else {
                            maze[i][j] = 0;
                        }
                        break;
                    }
                }
            }
            for (i = 0; i < HEIGHT; i++) {
                for (j = 0; j < WIDTH; j++) {
                    command = maze[i][j];
                    switch (command) {
                    case 1:
                        cout << "+";
                        break;
                    case 2:
                        cout << "-";
                        break;
                    case 3:
                        cout << "|";
                        break;
                    case 4:
                        cout << " ";
                        break;
                    default:
                        cout << " ";
                    }
                }
                cout << endl;
            }
            int n = 0;
            height_graph = HEIGHT / 2;
            width_graph = WIDTH / 2;
            term = height_graph * width_graph;
            graph = new node_pointer[term];
            for (i = 0; i < HEIGHT; i++) {
                for (j = 0; j < WIDTH; j++) {
                    if ((i % 2 != 0) && (j % 2 != 0)) {
                        node_pointer temp = new node;
                        temp->row = i;
                        temp->col = j;
                        temp->index = n;
                        temp->link[0] = NULL;
                        temp->link[1] = NULL;
                        temp->link[2] = NULL;
                        temp->link[3] = NULL;
                        graph[n++] = temp;
                    }
                }
            }
            n = 0;
            for (int i = 0; i < term; ++i) {
                node_pointer ptr = graph[n];
                int row = ptr->row;
                int col = ptr->col;
                int index = ptr->index;
                if (maze[row - 1][col] == 4)
                    ptr->link[0] = graph[index - width_graph];
                if (maze[row][col + 1] == 4)
                    ptr->link[1] = graph[index + 1];
                if (maze[row + 1][col] == 4)
                    ptr->link[2] = graph[index + width_graph];
                if (maze[row][col - 1] == 4)
                    ptr->link[3] = graph[index - 1];
                ++n;
            }
        }



        else {
            printf(" Needs a '.maz' extension\n");
            return false;
        }
    }
}




void ofApp::freeMemory() {
    for (int i = 0; i < HEIGHT; i++) {
        delete[] maze[i];
    }
    delete[] graph;
    delete[] maze;
}

bool ofApp::DFS()//DFSŽ���� �ϴ� �Լ�
{
    //TO DO
    //DFSŽ���� �ϴ� �Լ� ( 3����)
    return true;
}
void ofApp::dfsdraw()
{
    //TO DO 
    //DFS�� ������ ����� �׸���. (3���� ����)
}